# Cww-tech-africa-group-24-project
group 24 project
group project at cww tech africa cohort 2.0 2022.
calendar project.